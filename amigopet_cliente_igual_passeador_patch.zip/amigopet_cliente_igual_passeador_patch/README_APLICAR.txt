AmigoPet - Cliente igual ao Passeador

Corrige:
- Cliente com visual igual ao Passeador.
- Header com imagem no ícone.
- Card com imagem ajustada no quadro.
- Login Google limpo e funcionando.
- Remove botões antigos/confusos do login do cliente.

Aplicar:
cd E:\amigopet_app
git add frontend/index.html frontend/app.js frontend/styles.css frontend/assets/amigopet-banner.png
git commit -m "Deixar cliente igual ao passeador"
git push
