AmigoPet Patch 001 - Termo de Responsabilidade do Passeador

Arquivos modificados:
- backend/app/main.py
- frontend/passeador.html
- frontend/walker.js
- frontend/styles.css

O que foi adicionado:
- Colunas no usuário: accepted_terms, accepted_terms_at, terms_version
- Migração automática segura no startup
- Endpoint: POST /api/walkers/{id}/accept-terms
- Modal profissional dos termos no app do passeador
- Aceite obrigatório na primeira entrada do passeador
- Registro da versão do termo: 1.0

Aplicar no projeto:
1) Extraia este ZIP dentro de E:migopet_app substituindo os arquivos.
2) Rode:

cd E:migopet_app
git status
git add backend/app/main.py frontend/passeador.html frontend/walker.js frontend/styles.css
git commit -m "Adicionar termo de responsabilidade do passeador"
git push

Depois aguarde o Render ficar Live e teste /passeador.
