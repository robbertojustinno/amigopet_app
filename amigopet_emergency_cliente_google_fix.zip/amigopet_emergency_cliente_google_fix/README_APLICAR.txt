Correção emergencial Cliente

Corrige:
- Login Google do cliente que parou de funcionar.
- Remove confusão do botão "Entrar" no card.
- Reduz imagem gigante do cliente.
- Mantém filtro de passeadores offline no cliente.

Aplicar:
cd E:\amigopet_app
git add frontend/index.html frontend/app.js frontend/styles.css frontend/assets/amigopet-banner.png
git commit -m "Corrigir login Google cliente e banner"
git push
