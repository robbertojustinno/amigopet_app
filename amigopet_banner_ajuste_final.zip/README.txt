Cole este bloco NO FINAL do arquivo:

frontend/styles.css

Depois:

git add frontend/styles.css
git commit -m "Ajustar banner AmigoPet"
git push
