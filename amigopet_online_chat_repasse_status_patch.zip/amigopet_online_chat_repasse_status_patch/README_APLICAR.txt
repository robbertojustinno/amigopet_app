AmigoPet - Online/Offline + Chat Walker + Mensagem de Repasse

Alterado:
- backend/app/main.py
- frontend/app.js
- frontend/walker.js
- frontend/passeador.html
- frontend/styles.css

Correções:
1. Passeador online/offline agora salva no backend e atualiza o cliente via WebSocket.
2. Cliente passa a listar somente passeadores disponíveis.
3. Chat do cliente agora aparece/abre no app do passeador.
4. Passeador pode responder o cliente pelo chat.
5. Mensagem de repasse ajustada:
   💵 Repasse PIX solicitado com sucesso. Aguardando confirmação da instituição financeira.

Aplicar:
cd E:\amigopet_app
git add backend/app/main.py frontend/app.js frontend/walker.js frontend/passeador.html frontend/styles.css
git commit -m "Corrigir online chat e status do repasse"
git push
